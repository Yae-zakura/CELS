/**
 * 
 */
package com.ahstu.cles.dao;

import java.util.Set;

import org.junit.Test;

import com.ahstu.cles.dao.impl.BaseTermDaoImpl;
import com.ahstu.cles.entity.Vocabular;
import com.ahstu.cles.entity.Word;

/**
 * @description
 * @author 何章伟
 * @createDate 2017年6月13日 下午5:36:49
 * @version ver1.0
 * 
 */
public class BaseTermDaoImplTest {

	private IBaseTermDao dao = new BaseTermDaoImpl();

	@Test
	public void testGetAllWords() {
		//
		Set<Word> words = dao.getAllWords();
		//
		if (words != null) {
			for (Word w : words) {
				System.out.println(w);
			}
		}
		System.out.println("共计"+words.size());
	}
	@Test
	public void testGetAllVocabulars(){
		Set<Vocabular> vs=dao.getAllVocabular();
		//
		if(vs!=null){
			for(Vocabular v:vs){
				System.out.println(v);
			}
			
		}
		System.out.println("共计"+vs.size()+"个词组");
	}
}
