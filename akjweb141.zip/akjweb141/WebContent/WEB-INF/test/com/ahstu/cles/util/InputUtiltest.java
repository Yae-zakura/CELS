/**
 * 
 */
package com.ahstu.cles.util;

import org.junit.Test;

/**
 * @description
 * @author 何章伟
 * @createDate 2017年6月12日 下午4:01:31
 * @version ver1.0
 * 
 */
public class InputUtiltest {
	@Test
	public void testGetInt() {
		int i = InputUtil.getInt("请输入整数");
		System.out.println(i);
	}
	@Test
	public void testGetChar() {
		char c=InputUtil.getChar("请输入一个字母>");
		System.out.println(c);
	}
}
