package akjweb141;
//

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class AkjLogin extends HttpServlet{
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//super.doGet(req, resp);
			doPost(req, resp);// req,resp是传参，与doget方法相同，与dopost方法位数相对应
	}
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//super.doPost(req, resp);
		 String name = req.getParameter("akjname");
		 String password = req.getParameter("akjpassword");
		 if("admin".equals(name) && "admin".equals(password)){
			 req.setAttribute("names",name);
			 req.getRequestDispatcher("AkjMain.jsp").forward(req, resp);//转发Login
			 return;
		 }
		 resp.sendRedirect("AkjLogin.jsp");
		 return;
	}	
}
